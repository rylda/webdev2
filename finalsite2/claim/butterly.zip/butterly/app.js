const app = Vue.createApp({
    data() {
        return{
            showMovies: true, 
            title: 'Eraserhead',
            age: '2020',
            director: 'David Lynch'

        }

    },
    methods: {
        toggleShowMovies() {
            this.showMovies = !this.showMovies

        }
    }
    
})

app.mount('#app')